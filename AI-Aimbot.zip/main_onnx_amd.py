import onnxruntime as ort
import numpy as np
import pyautogui
import pygetwindow
import gc
import numpy as np
import cv2
import time
import win32api
import win32con
import pandas as pd
from utils.general import (cv2, non_max_suppression, xyxy2xywh)
import dxcam
import torch
import torch_directml
import inputs
import json, os
import pyautogui
import vgamepad as vg





def main():
    # Portion of screen to be captured (This forms a square/rectangle around the center of screen)
    screenShotHeight = 640
    screenShotWidth = 640

    # For use in games that are 3rd person and character model interferes with the autoaim
    # EXAMPLE: Fortnite and New World
    aaRightShift = 0

    # An alternative to aaRightShift
    # Mark regions of the screen where your own player character is
    # This will often prevent the mouse from drifting to an edge of the screen
    # Format is (minX, minY, maxX, maxY) to form a rectangle
    # Remember, Y coordinates start at the top and move downward (higher Y values = lower on screen)
    original_size = [320, 320]  # This was the original image size
    new_size = [640, 640]  # This is the new image size

    # Calculate the ratio of new / original size
    size_ratio = [new / original for new, original in zip(new_size, original_size)]

    skipRegions: list[tuple] = [
            (200, 230, screenShotWidth, screenShotHeight)
        ]
    # Scale the skip regions by the size ratio
    skipRegions = [(x * size_ratio[0], y * size_ratio[1], width * size_ratio[0], height * size_ratio[1])
                for x, y, width, height in skipRegions]

    # Autoaim mouse movement amplifier
    aaMovementAmp = 2.7

    # Person Class Confidence
    confidence = 0.30

    # What key to press to quit and shutdown the autoaim
    aaQuitKey = "Q"

    # If you want to main slightly upwards towards the head
    headshot_mode = False

    # Displays the Corrections per second in the terminal
    cpsDisplay = True

    # Set to True if you want to get the visuals
    visuals = False

    # Selecting the correct game window
    try:
        videoGameWindows = pygetwindow.getAllWindows()
        print("=== All Windows ===")
        for index, window in enumerate(videoGameWindows):
            # only output the window if it has a meaningful title
            if window.title != "":
                print("[{}]: {}".format(index, window.title))
        # have the user select the window they want
        try:
            userInput = int(input(
                "Please enter the number corresponding to the window you'd like to select: "))
        except ValueError:
            print("You didn't enter a valid number. Please try again.")
            return
        # "save" that window as the chosen window for the rest of the script
        videoGameWindow = videoGameWindows[userInput]
    except Exception as e:
        print("Failed to select game window: {}".format(e))
        return

    # Activate that Window
    activationRetries = 30
    activationSuccess = True
    while (activationRetries > 0):
        try:
            videoGameWindow.activate()
            activationSuccess = True
            break
        except pygetwindow.PyGetWindowException as we:
            print("Failed to activate game window: {}".format(str(we)))
            print("Trying again... (you should switch to the game now)")
        except Exception as e:
            print("Failed to activate game window: {}".format(str(e)))
            print("Read the relevant restrictions here: https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setforegroundwindow")
            activationSuccess = False
            activationRetries = 0
            break
        # wait a little bit before the next try
        time.sleep(3.0)
        activationRetries = activationRetries - 1
    # if we failed to activate the window then we'll be unable to send input to it
    # so just exit the script now
    if activationSuccess == False:
        return
    print("Successfully activated the game window...")

    # Setting up the screen shots
    sctArea = {"mon": 1, "top": videoGameWindow.top + (videoGameWindow.height - screenShotHeight) // 2,
                         "left": aaRightShift + ((videoGameWindow.left + videoGameWindow.right) // 2) - (screenShotWidth // 2),
                         "width": screenShotWidth,
                         "height": screenShotHeight}
    sctArea = {"mon": 1, "top": 0, "left": 0, "width": 1920, "height": 1080}

    # Starting screenshoting engine
    left = aaRightShift + \
        ((videoGameWindow.left + videoGameWindow.right) // 2) - (screenShotWidth // 2)
    top = videoGameWindow.top + \
        (videoGameWindow.height - screenShotHeight) // 2
    right, bottom = left + 320, top + 320

    region = (left, top, right, bottom)

    camera = dxcam.create(device_idx=0, region=region, max_buffer_len=5120)
    if camera is None:
        print("""DXCamera failed to initialize. Some common causes are:
        1. You are on a laptop with both an integrated GPU and discrete GPU. Go into Windows Graphic Settings, select python.exe and set it to Power Saving Mode.
         If that doesn't work, then read this: https://github.com/SerpentAI/D3DShot/wiki/Installation-Note:-Laptops
        2. The game is an exclusive full screen game. Set it to windowed mode.""")
        return
    camera.start(target_fps=160, video_mode=True)

    if visuals == True:
        # Create and Position the Live Feed window to the left of the game window
        cv2WindowName = 'Live Feed'
        cv2.namedWindow(cv2WindowName)
        visualsXPos = videoGameWindow.left - screenShotWidth - 5
        cv2.moveWindow(cv2WindowName, (visualsXPos if visualsXPos >
                       0 else 0), videoGameWindow.top)

    # Calculating the center Autoaim box
    cWidth = sctArea["width"] / 2
    cHeight = sctArea["height"] / 2

    # Used for forcing garbage collection
    count = 0
    sTime = time.time()

    so = ort.SessionOptions()
    so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    so.enable_mem_pattern = False
    ort_sess = ort.InferenceSession('best.onnx', sess_options=so, providers=[
                                    'DmlExecutionProvider'])

    # Used for colors drawn on bounding boxes
    COLORS = np.random.uniform(0, 255, size=(1500, 3))

    # Define the virtual input device for the Steam Controller
    gamepad = vg.VDS4Gamepad()
    # Initialize the move_x and move_y variables
    move_x = 0
    move_y = 0

    # Main loop Quit if Q is pressed
    last_mid_coord = None
    while win32api.GetAsyncKeyState(ord(aaQuitKey)) == 0:

        # Getting Frame
        cap = camera.get_latest_frame()
        if cap is None:
            continue

       # Convert image to array
        npImg = np.array(cap)

        # Check if image is 4-channel (like BGRA), if yes, convert to 3-channel (BGR)
        if npImg.shape[-1] == 4:
            bgr_image = cv2.cvtColor(npImg, cv2.COLOR_BGRA2BGR)
        else:
            bgr_image = npImg  # Assuming image is already 3-channel

        # Resize the image
        resized_image = cv2.resize(bgr_image, (640, 640))

        # Normalize and change datatype
        resized_image = resized_image / 255.0
        resized_image = resized_image.astype(np.float32)

        # Move color channel to correct position and add batch dimension
        resized_image = np.moveaxis(resized_image, -1, 0)
        resized_image = np.expand_dims(resized_image, axis=0)

        # Pass the resized and normalized image to the model
        outputs = ort_sess.run(None, {'images': resized_image})

        im = torch.from_numpy(outputs[0]).to('cpu')
        pred = non_max_suppression(
            im, confidence, confidence, 0, False, max_det=10)

        # Get targets from ML predictions
        targets = []
        for i, det in enumerate(pred):
            s = ""
            gn = torch.tensor(resized_image.shape)[[1, 2, 1, 2]] # Adjusted to resized image dimensions
            if len(det):
                for c in det[:, -1].unique():
                    n = (det[:, -1] == c).sum()  # detections per class
                    s += f"{n} {int(c)}, "  # add to string

                for *xyxy, conf, cls in reversed(det):
                    # normalized xywh
                    detTensorScreenCoords = (xyxy2xywh(torch.tensor(xyxy).view(
                        1, 4)) / gn).view(-1)
                    detScreenCoords = (
                        detTensorScreenCoords.tolist() + [float(conf)])
                    isSkipped = False
                    for skipRegion in skipRegions:
                        # TODO check logic. there are some rare edge cases.
                        # if min and max are both within the min and max of the other, then we are fully within it
                        detectionWithinSkipRegion = ((xyxy[0] >= skipRegion[0] and xyxy[2] <= skipRegion[2])
                                                     and (xyxy[1] >= skipRegion[1] and xyxy[3] <= skipRegion[3]))
                        # if above top edge, to the right of right edge, below bottom edge, or left of left edge, then there can be no intersection
                        detectionIntersectsSkipRegion = not (
                            xyxy[0] > skipRegion[2] or xyxy[2] < skipRegion[0] or xyxy[1] > skipRegion[3] or xyxy[1] < skipRegion[3])
                        if detectionWithinSkipRegion or detectionIntersectsSkipRegion:
                            isSkipped = True
                            break
                    if isSkipped == False:
                        targets.append(detScreenCoords)

        targets = pd.DataFrame(
            targets, columns=['current_mid_x', 'current_mid_y', 'width', "height", "confidence"])


        # If there are people in the center bounding box
        if len(targets) > 0:
            # Get the last persons mid coordinate if it exists
            if last_mid_coord:
                targets['last_mid_x'] = last_mid_coord[0]
                targets['last_mid_y'] = last_mid_coord[1]
                # Take distance between current person mid coordinate and last person mid coordinate
                targets['dist'] = np.linalg.norm(
                    targets.iloc[:, [0, 1]].values - targets.iloc[:, [4, 5]], axis=1)
                # This ensures the person closest to the crosshairs is the one that's targeted
                targets.sort_values(by="dist", ascending=False)

            # Take the first person that shows up in the dataframe (Recall that we sort based on Euclidean distance)
            xMid = targets.iloc[0].current_mid_x + aaRightShift
            yMid = targets.iloc[0].current_mid_y

            box_height = targets.iloc[0].height



            if headshot_mode:
                headshot_offset = box_height * 0.38
            else:
                headshot_offset = box_height * 0.2

            # Calculate the new position
            x_new = int((xMid - cWidth) + (move_x * aaMovementAmp))
            y_new = int(((yMid - headshot_offset) - cHeight) + (move_y * aaMovementAmp))

            # Convert the x_new and y_new values to a range between 0 and 255
            # Add checks to prevent DivisionByZero errors
            if 2 * cWidth != 0:
                x_new_scaled = int((x_new / (2 * cWidth)) * 255)
            else:
                x_new_scaled = 0  # or whatever default or error value you want

            if 2 * cHeight != 0:
                y_new_scaled = int((y_new / (2 * cHeight)) * 255)
            else:
                y_new_scaled = 0  # or whatever default or error value you want


            if win32api.GetKeyState(0x14):
                # Send raw input events to the game based on the controller input
                gamepad.right_joystick(x_new_scaled, y_new_scaled)
                # Update the virtual input device
                gamepad.update()

            last_mid_coord = [xMid, yMid]

        else:
            last_mid_coord = None

        # See what the bot sees
        if visuals:
            # Loops over every item identified and draws a bounding box
            for i in range(0, len(targets)):
                halfW = round(targets["width"][i] / 2)
                halfH = round(targets["height"][i] / 2)
                midX = targets['current_mid_x'][i]
                midY = targets['current_mid_y'][i]
                (startX, startY, endX, endY) = int(midX + halfW), int(midY +
                                                                      halfH), int(midX - halfW), int(midY - halfH)

                idx = 0
                # draw the bounding box and label on the frame
                label = "{}: {:.2f}%".format(
                    "Human", targets["confidence"][i] * 100)
                cv2.rectangle(cap, (startX, startY), (endX, endY),
                              COLORS[idx], 2)
                y = startY - 15 if startY - 15 > 15 else startY + 15
                cv2.putText(cap, label, (startX, y),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, COLORS[idx], 2)
            for skipRegion in skipRegions:
                cv2.rectangle(cap, (skipRegion[0], skipRegion[1]), (skipRegion[2],
                                                                    skipRegion[3]), (0, 0, 0), 2)

        # Forced garbage cleanup every second
        count += 1
        if (time.time() - sTime) > 1:
            if cpsDisplay:
                print("CPS: {}".format(count))
            count = 0
            sTime = time.time()

            # Uncomment if you keep running into memory issues
            # gc.collect(generation=0)

        # See visually what the Aimbot sees
        if visuals:
            cv2.imshow(cv2WindowName, cap)
            if (cv2.waitKey(1) & 0xFF) == ord('q'):
                cv2.destroyAllWindows()
                exit()
    camera.stop()


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        import traceback
        print("Please read the below message and think about how it could be solved.")
        traceback.print_exception(e)
        print(str(e))
        print("Please read the above message and think about how it could be solved.")
    cv2.destroyAllWindows()
